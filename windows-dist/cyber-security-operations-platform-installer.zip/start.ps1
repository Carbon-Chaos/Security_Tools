$ErrorActionPreference = 'Stop'

$nodeExe = $null
$nodeCandidates = @(
  "$env:ProgramFiles\nodejs\node.exe",
  "$env:ProgramFiles(x86)\nodejs\node.exe",
  "$env:LOCALAPPDATA\Programs\nodejs\node.exe"
)

foreach ($candidate in $nodeCandidates) {
  if ($candidate -and (Test-Path $candidate)) {
    $nodeExe = $candidate
    break
  }
}

if (-not $nodeExe) {
  $resolved = Get-Command node -ErrorAction SilentlyContinue
  if ($resolved) {
    $nodeExe = $resolved.Source
  } else {
    throw "Node.js was not found. Install Node.js LTS and ensure node.exe is available."
  }
}

$env:NODE_ENV = "production"
$env:HOST = "0.0.0.0"
$env:PORT = "3000"

& $nodeExe (Join-Path $PSScriptRoot 'server.js')
